import ReactDOM from 'react-dom/client';
import './index.css'
import App from './components/App/App';


//step 1 - make root element
const root = ReactDOM.createRoot(document.getElementById('root'));


root.render(
    <App/>
)


