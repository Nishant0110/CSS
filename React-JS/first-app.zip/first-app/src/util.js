const apiUrl ="https://jsonplaceholder.typicode.com/"


const requestAPIServer=(apiEndPoint,callbackFunction)=>{

    let api= apiUrl+ apiEndPoint;

    fetch(api).then(rawData=>rawData.json()).then(jsonData=> callbackFunction(jsonData) )


}

export {requestAPIServer}