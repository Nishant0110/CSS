import './App.css'

import Navbar from '../Navbar/Navbar'

import DataList from '../DataList/DataList'
import DataForm from '../DataForm/DataForm'
import { useState } from 'react'


export default function App(){

    const [currentPosition,setCurrentPosition]=useState(0)

    return(

        <div className="container_main">

            <Navbar  setCurrentPosition={setCurrentPosition} />

            {currentPosition==0 ? <DataList/> :<DataForm/> }


        </div>

    )

}