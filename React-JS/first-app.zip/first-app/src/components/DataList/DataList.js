import { useState } from 'react'
import { requestAPIServer } from '../../util'
import './DataList.css'

export default function DataList() {



    const [postData, setPostData] = useState([])

    const refreshDataList=(data)=>{
        setPostData(data)
    }


    requestAPIServer("posts",refreshDataList) // background 1-2 seconds

    return (<div>

        {postData.length==0 && <p>No Data avaialabale</p>}

        {postData.length!=0 && postData.map((item)=>{
            return <div className='item_div' > {item.userId}  {item.id} {item.title} {item.body}</div>
        })}

    </div>)
}