import './Navbar.css'

export default function Navbar(props){
    return(
        <nav className='nav_header'>
                <h1>My Web</h1>
                <ul className='nav_header_items'>
                    <li onClick={()=>{props.setCurrentPosition(0)}}><a href="#">List</a></li>
                    <li onClick={()=>{props.setCurrentPosition(1)}}><a href="#">Crete</a></li>
                </ul>
            </nav>
    )
}