export default function DataForm(){
    return(<p> This is Form</p>)
}